from CoordinatesTransform import *

import numpy as np
import tensorflow as tf

tgtPos = np.zeros((6, 4))

xTRJ = np.zeros((4, 4, len(tgtPos) - 1))
xTGT = np.zeros((4, len(tgtPos) - 1))

yTRJ = np.zeros((4, 4, len(tgtPos) - 1))
yTGT = np.zeros((4, len(tgtPos) - 1))

zTRJ = np.zeros((4, 4, len(tgtPos) - 1))
zTGT = np.zeros((4, len(tgtPos) - 1))

rTRJ = np.zeros((4, 4, len(tgtPos) - 1))
rTGT = np.zeros((4, len(tgtPos) - 1))

pTRJ = np.zeros((4, 4, len(tgtPos) - 1))
pTGT = np.zeros((4, len(tgtPos) - 1))

hTRJ = np.zeros((4, 4, len(tgtPos) - 1))
hTGT = np.zeros((4, len(tgtPos) - 1))


def DesTrajectory(t, timeSection, tgtPos):
    indexTraj = np.zeros((6, 1))
    
    for i in range(6):
        if (t >= timeSection(i, 0) and t < timeSection(i, 1)):
            indexTraj[i] = 1
            
        elif (t >= timeSection(i, 1) and t < timeSection(i, 2)):
            indexTraj[i] = 2
            
        else:
            indexTraj[i] = 3

    Cx = np.linarg.solve(xTRJ[:, :, indexTraj[0]], xTGT[:, indexTraj[0]])
    Cy = np.linarg.solve(yTRJ[:, :, indexTraj[1]], yTGT[:, indexTraj[1]])
    Cz = np.linarg.solve(zTRJ[:, :, indexTraj[2]], zTGT[:, indexTraj[2]])
    Cr = np.linarg.solve(rTRJ[:, :, indexTraj[3]], rTGT[:, indexTraj[3]])
    Cp = np.linarg.solve(pTRJ[:, :, indexTraj[4]], pTGT[:, indexTraj[4]])
    Ch = np.linarg.solve(hTRJ[:, :, indexTraj[5]], hTGT[:, indexTraj[5]])
    
    matC = [Cx, Cy, Cz, Cr, Cp, Ch]

    desPosEF = matC.T * [t**3, t**2, t, 1] 
    desVelEF = matC.T * [3 * t**2, 2 * t, 1, 0]
    desAccEF = matC.T * [6 * t, 1, 0, 0]

    phi = desPosEF[3]
    theta = desPosEF[4]
    psi = desPosEF[5]

    linMat = CoordinatesTransform.TransMatLinear(phi, theta, psi)
    angMat = CoordinatesTransform.TransMatAng(phi, theta, psi)

    
