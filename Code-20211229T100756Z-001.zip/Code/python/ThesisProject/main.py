import numpy as np
import math as m
from CoordinatesTransform import *
from DesiredTrajectory import *

""" Variables """ 

R2D = 180 / m.pi
D2R = m.pi / 180

timeSection = [ [0, 10, 20, 30], 
                [0, 10, 20, 30], 
                [0, 10, 20, 30], 
                [0, 10, 20, 30], 
                [0, 10, 20, 30], 
                [0, 10, 20, 30] ] 

targetPos = []
targetPos[:, 1] = [ [0, 0, 0], [0, 0, 0] * D2R ]
targetPos[:, 2] = [ [8, -10, 5], [0, 0, -30] * D2R ]
targetPos[:, 3] = [ [15, -3, 10], [0, 0, -90] * D2R ];
targetPos[:, 4] = [ [10, 5, 15], [0, 0, 0] * D2R ];

